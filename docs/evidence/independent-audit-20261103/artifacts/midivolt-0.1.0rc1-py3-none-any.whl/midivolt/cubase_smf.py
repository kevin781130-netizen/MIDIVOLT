"""Cubase-oriented Standard MIDI File (SMF) preflight and loss-audited export.

The exporter uses mido's event representation rather than pretty_midi's
higher-level reconstruction so CC, pitch bend, SysEx, text and marker events
survive wherever the SMF supports them. Cubase itself is not automated here.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from hashlib import sha256
import json
from pathlib import Path
import os
import tempfile

import mido

GLOBAL_META = frozenset(("set_tempo", "time_signature", "key_signature"))
MIN_PPQ = 24
MAX_PPQ = 960


def _read(path: str | Path) -> mido.MidiFile:
    source = Path(path)
    if source.suffix.lower() not in (".mid", ".midi"):
        raise ValueError("Standard MIDI file must end with .mid or .midi")
    if not source.is_file():
        raise FileNotFoundError(source)
    midi = mido.MidiFile(str(source))
    if midi.type not in (0, 1):
        raise ValueError("SMF type 2 is not supported by the Cubase interchange profile")
    if midi.ticks_per_beat <= 0:
        raise ValueError("SMF must have positive PPQ")
    return midi


def _events(track: mido.MidiTrack):
    absolute = 0
    for msg in track:
        absolute += msg.time
        if msg.type != "end_of_track":
            yield absolute, msg


def _track_end(track: mido.MidiTrack) -> int:
    """Absolute SMF end tick, including trailing end_of_track delta-time."""
    return sum(msg.time for msg in track)


def _song_end(midi: mido.MidiFile) -> int:
    return max((_track_end(track) for track in midi.tracks), default=0)


def _scale(tick: int, src_ppq: int, dst_ppq: int) -> int:
    # All SMF ticks are nonnegative; round half up for deterministic MIDI timing.
    return (tick * dst_ppq * 2 + src_ppq) // (2 * src_ppq)


def _signature(midi: mido.MidiFile, dest_ppq: int) -> Counter:
    events = Counter()
    for track in midi.tracks:
        for tick, msg in _events(track):
            item = msg.dict()
            item.pop("time", None)
            events[(_scale(tick, midi.ticks_per_beat, dest_ppq),
                    json.dumps(item, sort_keys=True, ensure_ascii=False))] += 1
    return events


def _musical_lane_signature(midi: mido.MidiFile, dest_ppq: int) -> Counter | None:
    """Audit musical track memberships without depending on track ordering.

    Type 0 has no independent lanes. In Type 1, conductor/global metadata
    may be relocated from any track to track 0 and musical events originally
    on track 0 may be moved to a separate track. Neither is track reassignment.
    Non-global events on tracks 1+ (including track names and controllers)
    must remain grouped with their original musical lane.
    """
    if midi.type != 1:
        return None
    lanes = Counter()
    for index, track in enumerate(midi.tracks):
        # Keep ordered events, not a multiset: at an identical tick, MIDI
        # Note Off -> Note On is not equivalent to Note On -> Note Off.
        items = []
        for tick, msg in _events(track):
            if msg.is_meta and msg.type in GLOBAL_META:
                continue
            if index == 0 and not hasattr(msg, "channel"):
                # _make_type1 moves track-0 metadata / SysEx to conductor.
                # The global event signature audits their values and times.
                continue
            data = msg.dict()
            data.pop("time", None)
            items.append((_scale(tick, midi.ticks_per_beat, dest_ppq),
                          json.dumps(data, sort_keys=True, ensure_ascii=False)))
        if items:
            lanes[tuple(items)] += 1
    return lanes


def _lanes_preserved(before: mido.MidiFile, after: mido.MidiFile,
                     dest_ppq: int) -> bool:
    if before.type == 0:
        # Splitting the single Type-0 track by channel is expected.
        return True
    return (after.type == 1 and
            _musical_lane_signature(before, dest_ppq) ==
            _musical_lane_signature(after, dest_ppq))


def _ordered_streams(midi: mido.MidiFile, dest_ppq: int, *, channels: bool = True) -> dict:
    """Keep same-tick order within channels and global meta streams.

    Channel splitting and conductor relocation remain permitted. Stable sorting
    follows the SMF track merge order for simultaneous cross-track events.
    """
    streams = defaultdict(list)
    for track in midi.tracks:
        for tick, msg in _events(track):
            if hasattr(msg, "channel") and channels:
                lane = ("channel", msg.channel)
            elif msg.type in GLOBAL_META or msg.type == "sysex":
                lane = ("meta", msg.type)
            else:
                continue
            data = msg.dict()
            data.pop("time", None)
            streams[lane].append((_scale(tick, midi.ticks_per_beat, dest_ppq),
                                  json.dumps(data, sort_keys=True, ensure_ascii=False)))
    return {lane: sorted(items, key=lambda item: item[0])
            for lane, items in streams.items()}


def _count_note_ons(midi: mido.MidiFile) -> int:
    return sum(
        1 for track in midi.tracks for msg in track
        if msg.type == "note_on" and msg.velocity > 0
    )


def _check_short_notes(midi: mido.MidiFile, dst_ppq: int):
    """Reject resolutions that collapse positive-duration notes into zero ticks."""
    for track in midi.tracks:
        starts = defaultdict(deque)
        for tick, msg in _events(track):
            if msg.type == "note_on" and msg.velocity > 0:
                starts[(msg.channel, msg.note)].append(tick)
            elif msg.type == "note_off" or (
                msg.type == "note_on" and msg.velocity == 0
            ):
                q = starts[(msg.channel, msg.note)]
                if q:
                    started = q.popleft()
                    if tick > started and _scale(tick, midi.ticks_per_beat, dst_ppq) <= (
                        _scale(started, midi.ticks_per_beat, dst_ppq)
                    ):
                        raise ValueError(
                            "PPQ conversion would collapse a positive-duration note; "
                            "choose a higher --ppq or preserve original timing"
                        )


def inspect_smf(path: str | Path) -> dict:
    midi = _read(path)
    counts = Counter(msg.type for track in midi.tracks for msg in track)
    misplaced = sum(
        1 for track in midi.tracks[1:] for msg in track
        if msg.is_meta and msg.type in GLOBAL_META
    )
    warnings = []
    if midi.type == 0:
        warnings.append("Type 0 combines all MIDI channels; export can split channels into Type 1.")
    if misplaced:
        warnings.append(
            f"{misplaced} global tempo/meter/key events are outside track 0; "
            "Cubase Type 1 export will relocate them to the conductor track."
        )
    if midi.ticks_per_beat > MAX_PPQ:
        warnings.append(
            f"Original PPQ {midi.ticks_per_beat} exceeds the optional "
            "24..960 export profile; conversion can quantize fine timing."
        )
    if counts["sysex"]:
        warnings.append("SysEx data is preserved in the SMF, but hardware/plugin behavior is not guaranteed.")
    if midi.type == 1 and len(midi.tracks) == 1:
        warnings.append("Type 1 has one track; Cubase multitrack arrangement not present.")
    return {
        "input": str(Path(path).resolve()),
        "sha256": sha256(Path(path).read_bytes()).hexdigest(),
        "type": midi.type,
        "ppq": midi.ticks_per_beat,
        "tracks": len(midi.tracks),
        "notes_on": _count_note_ons(midi),
        "tempo_events": counts["set_tempo"],
        "meter_events": counts["time_signature"],
        "key_events": counts["key_signature"],
        "control_changes": counts["control_change"],
        "pitch_bends": counts["pitchwheel"],
        "sysex_events": counts["sysex"],
        "nonconductor_global_meta": misplaced,
        "warnings": warnings,
    }


def _pack(events: list[tuple[int, mido.Message]], end_tick: int) -> mido.MidiTrack:
    track = mido.MidiTrack()
    before = 0
    for absolute, message in sorted(events, key=lambda x: x[0]):
        if absolute < before:
            raise ValueError("Negative event delta after normalization")
        track.append(message.copy(time=absolute - before))
        before = absolute
    track.append(mido.MetaMessage("end_of_track", time=max(0, end_tick - before)))
    return track


def _make_type1(midi: mido.MidiFile, ppq: int) -> mido.MidiFile:
    conductor: list[tuple[int, mido.Message]] = []
    tracks: list[list[tuple[int, mido.Message]]] = []
    ends: list[int] = []
    if midi.type == 0:
        per_channel: dict[int, list[tuple[int, mido.Message]]] = {}
        # The original Type-0 end_of_track may follow the final note by bars.
        # Preserve that tail on every split channel and the conductor lane.
        full_end = _scale(_track_end(midi.tracks[0]), midi.ticks_per_beat, ppq)
        for tick, msg in _events(midi.tracks[0]):
            new_tick = _scale(tick, midi.ticks_per_beat, ppq)
            if hasattr(msg, "channel"):
                per_channel.setdefault(msg.channel, []).append((new_tick, msg))
            else:
                conductor.append((new_tick, msg))
        for channel in sorted(per_channel):
            tracks.append(per_channel[channel])
            ends.append(full_end)
        conductor_end = full_end
    else:
        conductor_end = _scale(_song_end(midi), midi.ticks_per_beat, ppq)
        for index, original in enumerate(midi.tracks):
            musical: list[tuple[int, mido.Message]] = []
            end = _scale(_track_end(original), midi.ticks_per_beat, ppq)
            for tick, msg in _events(original):
                new_tick = _scale(tick, midi.ticks_per_beat, ppq)
                if msg.is_meta and msg.type in GLOBAL_META:
                    conductor.append((new_tick, msg))
                    conductor_end = max(conductor_end, new_tick)
                elif index == 0 and (msg.is_meta or msg.type == "sysex"):
                    # SysEx has no MIDI channel: when it originates on track 0
                    # it belongs to the conductor lane, not a new musical lane.
                    conductor.append((new_tick, msg))
                    conductor_end = max(conductor_end, new_tick)
                else:
                    musical.append((new_tick, msg))
            if musical:
                tracks.append(musical)
                ends.append(end)
    out = mido.MidiFile(type=1, ticks_per_beat=ppq)
    out.tracks.append(_pack(conductor, conductor_end))
    for events, end in zip(tracks, ends):
        out.tracks.append(_pack(events, end))
    return out


def prepare_smf(source: str | Path, destination: str | Path, *,
                ppq: int = 480) -> dict:
    """Export Type 1 conductor+multitrack SMF, never replacing source/existing files."""
    src = Path(source).expanduser().resolve()
    target = Path(destination).expanduser().resolve()
    if src == target:
        raise ValueError("Source and destination must differ")
    if not isinstance(ppq, int) or isinstance(ppq, bool) or not MIN_PPQ <= ppq <= MAX_PPQ:
        raise ValueError("Export PPQ must be 24..960")
    if target.suffix.lower() not in (".mid", ".midi") or not target.parent.is_dir():
        raise ValueError("Output must be .mid/.midi in an existing directory")
    if target.exists():
        raise FileExistsError(f"Refusing to overwrite {target}")
    midi = _read(src)
    _check_short_notes(midi, ppq)
    prepared = _make_type1(midi, ppq)
    if _signature(midi, ppq) != _signature(prepared, ppq):
        raise ValueError("Export changed one or more MIDI event values or tick positions")
    if not _lanes_preserved(midi, prepared, ppq):
        raise ValueError("Export changed original MIDI track membership")
    if _ordered_streams(midi, ppq, channels=midi.type == 0) != _ordered_streams(prepared, ppq, channels=midi.type == 0):
        raise ValueError("Export changed MIDI event order")
    expected_end = _scale(_song_end(midi), midi.ticks_per_beat, ppq)
    if _song_end(prepared) != expected_end:
        raise ValueError("Export changed MIDI song duration or trailing silence")
    fd, staging = tempfile.mkstemp(
        prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    os.close(fd)
    staged = Path(staging)
    try:
        prepared.save(str(staged))
        reopened = _read_mido_temp(staged)
        if _signature(midi, ppq) != _signature(reopened, ppq):
            raise ValueError("Serialized SMF roundtrip changed MIDI event content")
        if not _lanes_preserved(midi, reopened, ppq):
            raise ValueError("Serialized SMF roundtrip changed MIDI track membership")
        if _song_end(reopened) != expected_end:
            raise ValueError("Serialized SMF roundtrip changed MIDI song duration")
        try:
            os.link(staged, target)
        except FileExistsError as exc:
            raise FileExistsError(f"Refusing to overwrite {target}") from exc
    finally:
        staged.unlink(missing_ok=True)
    return {
        "source": str(src),
        "output": str(target),
        "type": 1,
        "ppq_original": midi.ticks_per_beat,
        "ppq_export": ppq,
        "tracks": len(prepared.tracks),
        "note_events": _count_note_ons(prepared),
        "all_midi_events_preserved_after_tick_rescale": True,
        "musical_track_membership_preserved": True,
        "song_duration_preserved_after_tick_rescale": True,
        "song_end_tick_original": _song_end(midi),
        "song_end_tick_export": expected_end,
        "source_sha256": sha256(src.read_bytes()).hexdigest(),
        "output_sha256": sha256(target.read_bytes()).hexdigest(),
        "timing_quantization_possible": midi.ticks_per_beat != ppq,
        "cubase_application_import_verified": False,
    }


def _read_mido_temp(path: Path) -> mido.MidiFile:
    return mido.MidiFile(str(path))


def compare_smf(reference: str | Path, returned: str | Path) -> dict:
    """Compare Cubase-exported result semantically, in original PPQ units."""
    before = _read(reference)
    after = _read(returned)
    # Canonical common PPQ is the product (not rounded fraction) so events
    # with differing PPQ have an exact tick-position comparison.
    common_ppq = before.ticks_per_beat * after.ticks_per_beat
    events_before = _signature(before, common_ppq)
    events_after = _signature(after, common_ppq)
    missing = events_before - events_after
    added = events_after - events_before
    lanes_preserved = _lanes_preserved(before, after, common_ppq)
    order_preserved = _ordered_streams(before, common_ppq, channels=before.type == 0) == _ordered_streams(after, common_ppq, channels=before.type == 0)
    # end_of_track is structurally reorganized for Type-0->Type-1 and
    # conductor relocation, so compare the *song end* rather than per-track
    # EOT messages. MIDI note events alone cannot detect trimmed trailing bars.
    original_end = _song_end(before)
    returned_end = _song_end(after)
    duration_preserved = (original_end * after.ticks_per_beat
                          == returned_end * before.ticks_per_beat)
    return {
        "source": str(Path(reference).resolve()),
        "roundtrip": str(Path(returned).resolve()),
        "reference_tracks": len(before.tracks),
        "returned_tracks": len(after.tracks),
        "note_on_reference": _count_note_ons(before),
        "note_on_returned": _count_note_ons(after),
        "exact_event_match": not missing and not added and duration_preserved and lanes_preserved and order_preserved,
        "event_order_preserved": order_preserved,
        "musical_track_membership_preserved": lanes_preserved,
        "song_duration_preserved": duration_preserved,
        "reference_end_tick": original_end,
        "returned_end_tick": returned_end,
        "reference_ppq": before.ticks_per_beat,
        "returned_ppq": after.ticks_per_beat,
        "missing_events": sum(missing.values()),
        "added_events": sum(added.values()),
        "warning": (
            "Strict comparison includes metadata, track names, program/CC and "
            "tempo events. Cubase may intentionally transform them based on import "
            "options; inspect its preferences and exported file."
        ),
        "cubase_import_verified": False,
    }
